//
//  main.m
//  百思不得姐-01
//
//  Created by 我演示 on 2019/9/9.
//  Copyright © 2019 我演示. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
